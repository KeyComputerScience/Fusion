# Frozen RSS pairing and distributional-shape diagnostic

This directory adds a diagnostic on the five **already known RSS development** delay seeds 88001–88005. It adds no source, tuning choice or replacement operational controller. Frozen scientific inputs and sources were hash-locked in `protocol.json` before this run. The prior primary outputs remain unchanged.

For each of 210 frozen CJ origins, the run holds the mature archive, active sources, current forecasts, quality, bandwidth, information-readiness mask, causally issued CJ threshold, costs and complete fork fixed. It replaces only the fitted residual density with

\[
f_\tau=(1-\tau)f_0+\tau f_1,\qquad
p_\tau(u\mid h)\propto\mathbf1_{[-1,1]}(u)f_\tau(h-u\mathbf1),
\quad\tau\in\{0,.25,.5,.75,1\}.
\]

The three families are:

* `product_to_joint`: product of the exact coordinate mixture marginals to the paired mixture. Every coordinate density is identical across the bridge, while dependence and covariance change.
* `product_to_joint_diagP`: the same product endpoint to a paired mixture with the correction covariance replaced by its diagonal. The coordinate marginal densities remain identical; joint innovation pairing remains while correction-covariance off-diagonals are removed.
* `gaussian_to_joint`: the Gaussian having exactly the paired residual mean and full covariance to the paired mixture. Every bridge level has those same residual moments, so the response reflects distributional shape beyond the first two moments. Coordinate density shapes need not be identical in this family.

Mixing happens **before** target-line normalization. The posterior joint weight is therefore `tau * evidence_joint / evidence_bridge`, which generally differs from `tau`. The variance includes the between-endpoint posterior-mean term. Scores use `F = N * posterior_mean` when information-ready (and the frozen `F=0` otherwise), `S = N * sqrt(posterior_variance + norm_floor**2)` and `F - q*S - 5`. The theory paid-score formulas apply to information-ready origins.

All 15 guarded mean increments under the shared Fixed130/B130 ledger are shown below. Values are increments over common service, averaged over the five delay seeds.

| Fitted-density bridge | 0 | .25 | .5 | .75 | 1 |
|---|---:|---:|---:|---:|---:|
| Product → joint | 16.8 | 16.8 | 16.8 | 34.4 | 35.6 |
| Product → joint, diagonal P | 16.8 | 16.8 | 16.8 | 28.8 | 35.6 |
| Same-mean/covariance Gaussian → joint | 16.8 | 16.8 | 24.4 | 28.8 | 35.6 |

Each endpoint retains all nine baseline beneficial admissions. At `tau=1`, five additional positive proposed leases have complete utilities **6, 22, 38, 28 and 19** (total 113). The ledger executes the first four (total 94), producing the mean gain 18.8; it refuses the final 19 after the common one-unit loss consumes permanent liability. Every level retains the same single harmful lease and one-unit aggregate loss. The endpoint has 16 guarded admissions: 13 beneficial, one harmful and two zero-return. Its realized admitted lower-bound coverage is **11/16**. The full outcomes, including all losses and refusals, are retained. These development observations do not imply monotone benefit in general, improved true-law calibration or superiority over every operational method; the previously reported legacy controllers and the separate frozen physical validation remain relevant.

`summary.json` and `summary.csv` contain every bridge level, seed return vector, admissions, coverage, losses and four-term action accounting. `predictions.csv` contains all 3,150 numerical forecasts. `changed_actions.csv` contains every changed proposal and guarded action; `mechanism_cases.csv` gives all five endpoint-crossing origins at every bridge level. `results.json.gz` retains full rows, guarded rows and ledgers. `state_audit.json.gz` retains all endpoint and numerical checks.

The main run reconstructs explicit served-request utility and prefix utility independently of summed fork utilities. Their maximum discrepancy is zero. All maturity and budget checks pass. Frozen endpoint posterior moments agree within `2.64e-16`; paired diagonal-P coordinate variances agree within `6.94e-18`; the Gaussian bridge's residual moments agree within `5.55e-17`. Successive quadrature grids agree within `8.88e-16` using at most 512 nodes. This last value is a refinement diagnostic, **not a rigorous integration-error bound**. The mixture-moment check uses the same quadrature, so it verifies the algebra rather than independently certifying integration accuracy.

`bridge_math.py` receives only the current forecast and frozen fitted-law arrays. Current complete fork labels are used afterward for offline callback/accounting. The main script's 210 poison-input checks check input isolation only, not an end-to-end leakage experiment. The unchanged original causal audit supplies the broader forecasting provenance.

## Portable numeric replay

`cached_states.json.gz` stores lossless JSON round-trip values of `h`, mixture weights, locations, covariances, residual mean/full covariance, correction covariance, N, frozen q/readiness, norm floor, complete fork utility/gross gain, maturity, immutable fork IDs and original row hashes. `cached_manifest.json` records source and output hashes. Its cached-input SHA256 is:

`911fd4b34a3f568984b9baaaabd7c55397676a857bd8cf9017103057b1c7e5ec`

With Python and NumPy available, run:

```sh
python3 verify_cached.py
```

Only six local files are needed: `bridge_math.py`, `verify_cached.py`, `cached_states.json.gz`, `cached_manifest.json`, `predictions.csv` and `summary.json`. The verifier does not import the parent experiment engine or physical datasets. It checks all posterior moments, F/S/scores/proposals and guarded seed totals, with zero discrepancy in the saved run. It does not reconstruct physical request service or verify each saved guard action, evidence, coverage or four-term quantity. Those full records and the main service checks are retained in this directory and the unchanged dependency archive. `portable_verification.json` records a successful replay from a fresh temporary directory containing only these six files. `export_evidence.py` creates the derived case tables and performs that isolation check without changing scientific outputs.

The original scientific run is already complete and refuses to overwrite its outputs. `run_pairing_bridge.py` preserves the live-state regeneration procedure; `bridge_math.py` and the cached verifier provide the standalone rerun path.
