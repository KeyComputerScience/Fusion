"""Read-only CJ-Q API and delayed-state audit; constructed laws only.

Audits retained calibration logs when available. Opens no physical trace.
"""
from pathlib import Path
import gzip
import hashlib
import importlib.util
import json
import math
import sys
import numpy as np

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[2]
PATH=HERE.parent/'design_quantile/quantile.py'
sp=importlib.util.spec_from_file_location('independent_quantile_actual_api',PATH)
api=importlib.util.module_from_spec(sp);sp.loader.exec_module(api)
sp=importlib.util.spec_from_file_location('independent_quantile_reference',HERE/'verify_quantile_theory.py')
reference=importlib.util.module_from_spec(sp);sp.loader.exec_module(reference)


def independent_line(h,alpha,locations,covariances):
    one=np.ones(len(h));means=[];sd=[];logweights=[]
    for a,loc,S in zip(alpha,locations,covariances):
        inv=np.linalg.inv(S);variance=1/(one@inv@one);r=h-loc
        mean=float(variance*(one@inv@r));perp=float(r@inv@r-mean**2/variance)
        means.append(mean);sd.append(math.sqrt(variance))
        logweights.append(math.log(a)-.5*np.linalg.slogdet(S)[1]-.5*perp+.5*math.log(variance))
    w=np.exp(np.array(logweights)-max(logweights))
    return reference.IndependentMixture(w,means,sd)


def independent_density_cdf(law,u,bins=128):
    x,w=np.polynomial.legendre.leggauss(8)
    def interval(left,right,shift):
        half=(right-left)/(2*bins);mid=left+(np.arange(bins)+.5)*(right-left)/bins
        points=(mid[:,None]+half*x[None,:]).ravel()
        weights=np.tile(half*w,bins)
        return float(weights@np.exp(law.logdensity(points)-shift))
    target=np.linspace(-1,1,4097)
    shift=float(law.logdensity(target).max())
    total=interval(-1,1,shift)
    if u<=-1:return 0.
    if u>=1:return 1.
    return interval(-1,u,shift)/total


def numerical_api_checks():
    rng=np.random.default_rng(101042026)
    analytic_error=quadrature_error=quantile_error=bracket_width=0.;cases=0
    for m in (1,2,4):
        for count in (1,4):
            alpha=rng.dirichlet(np.ones(count));locations=rng.uniform(-.3,.3,(count,m))
            r=rng.normal(0,.08,(count,m,m));covariances=np.einsum('jst,jut->jsu',r,r)+np.eye(m)[None]*.01
            h=rng.uniform(-.4,.4,m)
            actual=api.AnalyticLaw(h,alpha,locations,covariances)
            expected=independent_line(h,alpha,locations,covariances)
            for u in np.linspace(-1,1,41):analytic_error=max(analytic_error,abs(actual.cdf(u)-expected.cdf(u)))
            for beta in (1e-4,.01,.05,.1,.25,.5,.9):
                a=actual.quantile(beta);e=expected.quantile(beta)
                assert a['cdf_lower']<=beta+1e-14 and a['cdf_upper']>=beta-1e-14
                bracket_width=max(bracket_width,a['width']);quantile_error=max(quantile_error,abs(a['value']-e[0]))
            weights=alpha;center=weights@locations;v=locations-center
            C=np.einsum('j,jst->st',weights,covariances)+np.einsum('j,js,jt->st',weights,v,v)
            for copula in (False,True):
                numerical=api.QuadratureLaw(h,alpha,locations,covariances,C if copula else None)
                for u in (-.8,-.4,0.,.4,.8):
                    quadrature_error=max(quadrature_error,abs(numerical.cdf(u)-independent_density_cdf(numerical,u)))
                for beta in (1e-4,.01,.1,.25,.5):
                    q=numerical.quantile(beta)
                    assert q['cdf_lower']<=beta+1e-12 and q['cdf_upper']>=beta-1e-12
                    quadrature_error=max(quadrature_error,abs(independent_density_cdf(numerical,q['value'])-beta))
            cases+=1
    assert analytic_error<1e-12 and quantile_error<1e-10 and quadrature_error<1e-8
    return dict(passed=True,constructed_error_laws=cases,dimensions=[1,2,4],
                exact_line_cdf_error=analytic_error,analytic_quantile_error=quantile_error,
                product_copula_cdf_and_quantile_independent_integration_error=quadrature_error,
                analytic_max_quantile_bracket_width=bracket_width)


def synthetic_run_checks():
    N=128;pre=dict(q=np.ones(2));cfg=dict(cap=.8,slice_bandwidth=.5,norm_floor=.01,beta_cap=.25,threshold=0.,deploy_drop=2)
    means=np.array([-.2,.118/.91]);alpha=np.array([.09,.91]);covs=np.repeat((np.eye(2)*.0002)[None],2,axis=0)
    def law():return api.AnalyticLaw(np.zeros(2),alpha,-means[:,None]*np.ones((2,2)),covs)
    laws=[law() for _ in range(5)]
    # Mutate a prior test object's CDF after its rank was issued. The callback
    # must use the saved scalar rank; no production source is modified.
    original_quantile=laws[2].quantile
    def later_quantile(beta):
        laws[1].cdf=lambda u:0.
        return original_quantile(beta)
    laws[2].quantile=later_quantile
    targets=[0,16,-32,8,0];maturities=[4,10,9,17,24];decisions=[]
    for j,(gross,maturity,dist) in enumerate(zip(targets,maturities,laws)):
        k=4*j;eligible=[] if j==0 else [dict(origin=0,maturity=4,weight=1.)]
        mm=dict(quantile_laws={'q_joint':dist},eligible=eligible,mu=np.zeros(2),R=np.eye(2)*.01,
                P=np.eye(2)*.01,non_scalar=0.,partial_blocks=0)
        decisions.append(dict(k=k,N=N,ids=np.arange(2),temporal=mm,truegross=float(gross),localnet=float(gross-5),
            grossdifference=float(gross-2),accdifference=0,disagreement=1.,maturity=maturity,
            future=[],blocks=1,mass=2.,scale=1.))
    stream=dict(basegross=0.,commonfees=0.,commondrops=0,basecorrect=0,n=640,windows=20,decisions=decisions)
    result=api.run_quantile(None,stream,pre,cfg,'q_joint',.1)
    rows=result['rows'];updates=result['beta_updates']
    assert [x['issued_index'] for x in updates]==[8,4,12]
    assert not any(x['issued_index']==0 for x in updates)
    assert not rows[0]['action'] and not rows[0]['pre_gate_proposal']
    assert updates[1]['cdf_rank']==rows[1]['cdf_rank']>.1
    assert updates[1]['violation']==0
    assert updates[0]['violation']==1
    assert abs(rows[3]['beta_issued']-.06)<1e-14
    assert not rows[3]['action'] and updates[2]['issued_index']==12
    assert not any(x['issued_index']==16 for x in updates)
    assert abs(result['calibration_identity_error'])<1e-14
    initial,ranks=api.initial_beta([stream],pre,cfg,'q_joint')
    # Only k=4,8 are ready and mature by half=10; k=0 is unready and 12/16 late.
    assert len(ranks)==2 and initial>=1e-4
    poisoned=api.forecast(dict(decisions[3],truegross=1e20),pre,cfg,'q_joint',.06)
    clean=api.forecast(decisions[3],pre,cfg,'q_joint',.06)
    assert clean[2:4]==poisoned[2:4] and clean[4]!=poisoned[4]
    return dict(passed=True,unready_callback_excluded=True,rejected_ready_callback_released=True,
        pending_after_replay_end_preserved=True,callback_order=[x['issued_index'] for x in updates],
        frozen_issued_rank_survives_later_test_law_change=True,initial_fit_ready_mature_firsthalf_rank_count=len(ranks),
        delayed_beta_identity_error=result['calibration_identity_error'],truth_poison_issuance_error=0.)


def retained_log_checks():
    root=PATH.parent;path=root/'rss348_calibration_trials.json.gz'
    if not path.exists():return dict(passed=False,reason='Calibration retained logs not available yet.')
    protocol=json.loads((root/'protocol.json').read_text())
    assert protocol['source_hashes'][str(PATH)]==hashlib.sha256(PATH.read_bytes()).hexdigest()
    with gzip.open(path,'rt') as f:trials=json.load(f)
    results=[]
    for trial in trials:
        if trial['configuration']['arm'] not in api.NEW_ARMS:continue
        for result in trial['results']:
            rows={x['k']:x for x in result['rows']};updates=result['beta_updates']
            for update in updates:
                row=rows[update['issued_index']]
                assert row['information_ready']
                assert update['maturity']<=update['update_index']
                assert update['beta_issued']==row['beta_issued']
                assert update['cdf_rank']==row['cdf_rank']
                assert update['quantile_issued']==row['quantile']
                assert update['violation']==int(row['cdf_rank']<row['beta_issued'])
            count=len(updates);violations=sum(x['violation'] for x in updates);reg=sum(x['regulator'] for x in updates)
            predicted=.1*count+(result['beta_initial']-result['beta_final']+reg)/.05
            error=abs(violations-predicted)
            assert error<1e-8
            assert not any(x['pre_gate_proposal'] for x in rows.values() if not x['information_ready'])
            for row in rows.values():
                if row['lower_covered']:assert row['local_net']>=row['paid_lower_bound']-1e-8
            results.append(dict(rows=len(rows),updates=count,error=error,
                rejected_callbacks=sum(not rows[x['issued_index']]['action'] for x in updates)))
    return dict(passed=True,quantile_calibration_trajectories=len(results),
        issued_rows=sum(x['rows'] for x in results),callbacks=sum(x['updates'] for x in results),
        rejected_ready_callbacks=sum(x['rejected_callbacks'] for x in results),
        max_beta_identity_error=max(x['error'] for x in results),frozen_source_hash_verified=True,
        issued_rank_beta_quantile_match_every_callback=True,all_covered_rows_satisfy_paid_lower_bound=True)


if __name__=='__main__':
    report=dict(scope='Read-only constructed API and retained-log audit; no physical trace read.',
        source=str(PATH),source_sha256=hashlib.sha256(PATH.read_bytes()).hexdigest(),
        numerical=numerical_api_checks(),synthetic_delayed_run=synthetic_run_checks(),retained_logs=retained_log_checks())
    out=HERE/'quantile_api_report.json';out.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(output=str(out),numerical=report['numerical'],synthetic=report['synthetic_delayed_run'],
                         retained=report['retained_logs']),indent=2))
