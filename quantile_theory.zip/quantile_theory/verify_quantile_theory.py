"""Constructed CJ-Q CDF, paid-certificate and delayed-feedback checks.

No physical data are read. Actual API checks are added once the source exists.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import sys
import numpy as np

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent


def Phi(x):
    return .5*math.erfc(-float(x)/math.sqrt(2))


def interval_mass(left,right):
    return Phi(right)-Phi(left) if left<0 else Phi(-left)-Phi(-right)


class IndependentMixture:
    def __init__(self,alpha,mean,sd):
        self.mean=np.asarray(mean,dtype=float)
        self.sd=np.asarray(sd,dtype=float)
        self.Z=np.array([interval_mass((-1-m)/s,(1-m)/s) for m,s in zip(self.mean,self.sd)])
        mass=np.asarray(alpha,dtype=float)*self.Z
        assert np.all(self.Z>0)
        self.weight=mass/mass.sum()

    def cdf(self,u):
        if u<=-1:return 0.
        if u>=1:return 1.
        result=sum(w*interval_mass((-1-m)/s,(u-m)/s)/Z
                   for w,m,s,Z in zip(self.weight,self.mean,self.sd,self.Z))
        return min(1.,max(0.,float(result)))

    def quantile(self,beta):
        assert 0<beta<1
        lo,hi=-1.,1.
        for _ in range(80):
            mid=.5*(lo+hi);rank=self.cdf(mid)
            if rank==beta:
                lo=hi=mid;break
            if rank<beta:lo=mid
            else:hi=mid
            if hi-lo<1e-12:break
        return lo,hi,self.cdf(lo),self.cdf(hi)


def cdf_and_quantile_checks():
    rng=np.random.default_rng(102026)
    laws=[IndependentMixture([1],[0],[.2]),IndependentMixture([.09,.91],[-.2,.118/.91],[.01,.01]),
          IndependentMixture([.4,.6],[-1.3,1.2],[.15,.12])]
    laws += [IndependentMixture(rng.dirichlet(np.ones(5)),rng.uniform(-.7,.7,5),rng.uniform(.02,.15,5)) for _ in range(5)]
    maximum_width=0.;maximum_residual=0.;checked=0
    for law in laws:
        grid=np.linspace(-1,1,2001)
        values=np.array([law.cdf(u) for u in grid])
        assert values[0]==0 and values[-1]==1 and np.min(np.diff(values))>=-1e-15
        last=-1.
        for beta in (1e-4,.01,.05,.1,.25,.5,.9,.99,1-1e-4):
            lo,hi,cl,ch=law.quantile(beta)
            assert cl<=beta+1e-15 and ch>=beta-1e-15 and lo>=last
            assert hi-lo<1.1e-12
            maximum_width=max(maximum_width,hi-lo)
            maximum_residual=max(maximum_residual,abs(cl-beta),abs(ch-beta))
            # Strict saved-rank coverage implies the conservative issued
            # lower bracket's complete-return certificate on every grid point.
            N=128;L=N*lo-5
            for U in grid:
                if law.cdf(U)>=beta:
                    assert N*U-5+0.7 >= L-1e-12
            checked+=1;last=lo
    symmetric=laws[0]
    tie_rank=symmetric.cdf(0)
    assert abs(tie_rank-.5)<1e-15
    lo,hi,cl,ch=symmetric.quantile(tie_rank)
    assert lo==hi==0 and cl==ch==tie_rank
    assert not (symmetric.cdf(0)<tie_rank)
    assert symmetric.cdf(-1e-6)<.5<symmetric.cdf(1e-6)
    return dict(passed=True,laws=len(laws),quantiles=checked,max_bracket_width=maximum_width,
                max_cdf_bracket_residual=maximum_residual,strict_computed_rank_tie_covered=True,
                symmetric_median_cdf_roundoff=abs(tie_rank-.5),
                conservative_lower_bracket_certificate_grid_check=True)


def shape_checks():
    # Both law shapes have the same raw mean/variance; bounds are remote.
    weights=np.array([.09,.91]);means=np.array([-.2,.118/.91]);sd=.01
    mean=float(weights@means)
    variance=float(sd**2+weights@((means-mean)**2))
    mixed=IndependentMixture(weights,means,[sd,sd])
    gaussian=IndependentMixture([1],[mean],[math.sqrt(variance)])
    mq=mixed.quantile(.1)[0];gq=gaussian.quantile(.1)[0]
    joint_score,gaussian_score=128*mq-5,128*gq-5
    moment_score=128*mean-1.2815515655446004*128*math.sqrt(variance+.01**2)-5
    assert joint_score>0>gaussian_score and moment_score<0
    return dict(passed=True,raw_mean=mean,raw_variance=variance,beta=.1,
                mixture_quantile=mq,gaussian_quantile=gq,mixture_paid_score=joint_score,
                moment_matched_gaussian_paid_score=gaussian_score,old_mean_sd_paid_score=moment_score,
                scope='Posterior-shape mechanism; no physical superiority claim.')


def feedback_checks():
    alpha,gamma=.1,.05
    beta0,cap=.1,.1;beta=beta0;regulators=[];updates=[]
    violations=[0,0,1,1,1,1,0,0,0]
    for v in violations:
        proposal=beta+gamma*(alpha-v)
        new=min(cap,max(1e-4,proposal))
        regulator=new-beta-gamma*(alpha-v)
        regulators.append(regulator);updates.append(dict(before=beta,after=new,violation=v,regulator=regulator))
        beta=new
    predicted=alpha*len(violations)+(beta0-beta+sum(regulators))/gamma
    error=abs(sum(violations)-predicted)
    assert error<1e-14
    assert min(regulators)<0<max(regulators)
    issued=IndependentMixture([1],[.2],[.01])
    updated=IndependentMixture([1],[0],[.01])
    target=.15;issued_rank=issued.cdf(target);updated_rank=updated.cdf(target)
    assert issued_rank<.1<updated_rank
    return dict(passed=True,updates=updates,violation_count=sum(violations),identity_error=error,
                regulator_both_signs=True,saved_issuance_rank=issued_rank,later_law_rank=updated_rank,
                recomputing_rank_with_later_law_changes_violation=True,
                all_ready_issued_callback_scope='Rejection does not remove a callback; acceptance is not the calibration denominator.')


if __name__=='__main__':
    report=dict(scope='Constructed checks only; no physical data read.',cdf_quantile=cdf_and_quantile_checks(),
                shape=shape_checks(),delayed_feedback=feedback_checks(),runtime=dict(python=sys.version,numpy=np.__version__))
    output=HERE/'quantile_theory_report.json'
    output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(output=str(output),passed=True,
        mixture_score=report['shape']['mixture_paid_score'],gaussian_score=report['shape']['moment_matched_gaussian_paid_score'],
        beta_identity_error=report['delayed_feedback']['identity_error']),indent=2))
