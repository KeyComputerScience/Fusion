"""Independent reconstruction of retained known-RSS CJ-Q logs, not HARTH."""
from pathlib import Path
import gzip
import hashlib
import json
import math
import numpy as np

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[2]
ROOT = HERE.parent/'design_quantile'
QUANTILE_ARMS = ('q_joint', 'q_product', 'q_factorized', 'q_gaussian',
                 'q_sandwich', 'q_copula', 'q_joint_diagP')


def load(path):
    if str(path).endswith('.gz'):
        with gzip.open(path, 'rt') as stream:
            return json.load(stream)
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def near(a, b):
    assert abs(a-b) < 1e-10, (a, b)


def reconstruct(result, config, windows, selection):
    beta = result['beta_initial']
    near(beta, config['initial'])
    cap = config['beta_cap']
    boundary = windows//2 if selection else 0
    pending, expected, err, rank_ties = [], [], 0., []
    by_origin = {row['k']: row for row in result['rows']}
    assert len(by_origin) == len(result['rows'])
    def release(now):
        nonlocal beta, pending
        for row in sorted(pending, key=lambda row: row['maturity']):
            if row['maturity'] > now:
                continue
            v = int(row['cdf_rank'] < row['beta_issued'])
            proposal = beta+.05*(.1-v)
            after = min(cap, max(1e-4, proposal))
            expected.append(dict(maturity=row['maturity'], issued_index=row['k'], update_index=now,
                beta_issued=row['beta_issued'], cdf_rank=row['cdf_rank'], quantile_issued=row['quantile'],
                violation=v, beta_before=beta, beta_after=after, regulator=after-proposal))
            beta = after
        pending = [row for row in pending if row['maturity'] > now]
    for row in result['rows']:
        release(row['k'])
        near(row['beta_issued'], beta)
        assert 1e-4 <= beta <= cap
        assert row['information_ready'] == bool(row['eligible'])
        assert all(block['maturity'] <= row['k'] for block in row['eligible'])
        assert row['rank_covered'] == (row['cdf_rank'] >= row['beta_issued'])
        assert row['lower_covered'] == (row['complete_target'] >= row['quantile'])
        assert 0 <= row['cdf_rank'] <= 1
        assert row['quantile_cdf_lower'] <= beta+1e-12
        assert row['quantile_cdf_upper'] >= beta-1e-12
        assert row['quantile'] <= row['quantile_upper']
        near(row['quantile_upper']-row['quantile'], row['quantile_bracket_width'])
        near(row['paid_lower_bound'], row['gain']-5)
        near(row['gate_score'], row['gain']-5)
        assert row['pre_gate_proposal'] == (row['information_ready'] and row['gate_score'] > 0)
        assert row['action'] == (row['pre_gate_proposal'] and row['k'] >= boundary)
        if row['rank_covered'] and not row['lower_covered']:
            gap = row['quantile']-row['complete_target']
            assert gap <= 4e-13, (config, row['k'], gap)
            rank_ties.append(dict(k=row['k'], action=row['action'], target_quantile_gap=gap,
                cdf_rank=row['cdf_rank'], beta=row['beta_issued']))
        if row['lower_covered']:
            assert row['local_net'] >= row['paid_lower_bound']-1e-8
        if row['information_ready'] and row['k'] >= boundary:
            pending.append(row)
    release(windows)
    updates = result['beta_updates']
    assert len(expected) == len(updates)
    for one, two in zip(expected, updates):
        assert set(one) == set(two)
        for key in one:
            err = max(err, abs(one[key]-two[key]))
            near(one[key], two[key])
        row = by_origin[two['issued_index']]
        assert row['information_ready'] and two['maturity'] <= two['update_index']
    near(beta, result['beta_final'])
    regulator = sum(update['regulator'] for update in updates)
    violations = sum(update['violation'] for update in updates)
    identity = abs(violations-(.1*len(updates)+(result['beta_initial']-beta+regulator)/.05))
    near(regulator, result['clip_regulator_sum'])
    assert identity < 1e-8
    near(sum(row['local_net'] for row in result['rows'] if row['action']), result['selection_net'])
    assert abs(result['closed_loop_identity_error']) < 1e-8
    return dict(rows=len(by_origin), callbacks=len(updates), pending=len(pending),
        rejected_ready_callbacks=sum(not by_origin[update['issued_index']]['action'] for update in updates),
        positive_clip_regulators=sum(update['regulator'] > 0 for update in updates),
        negative_clip_regulators=sum(update['regulator'] < 0 for update in updates),
        floating_rank_quantile_ties=rank_ties,
        max_update_reconstruction_error=err, identity_error=identity)


def combine(results):
    return dict(trajectories=len(results), issued_rows=sum(x['rows'] for x in results),
        callbacks=sum(x['callbacks'] for x in results), pending_at_replay_end=sum(x['pending'] for x in results),
        rejected_ready_callbacks=sum(x['rejected_ready_callbacks'] for x in results),
        positive_clip_regulators=sum(x['positive_clip_regulators'] for x in results),
        negative_clip_regulators=sum(x['negative_clip_regulators'] for x in results),
        floating_rank_quantile_ties=[tie for x in results for tie in x['floating_rank_quantile_ties']],
        max_callback_reconstruction_error=max(x['max_update_reconstruction_error'] for x in results),
        max_beta_identity_error=max(x['identity_error'] for x in results))


def guarded_rows(result, budget):
    acts = [row for row in result['rows'] if row['action']]
    near(sum(row['local_net'] for row in acts), result['increment'])
    near(sum(max(0., -row['local_net']) for row in acts), result['loss'])
    assert result['loss'] <= budget+1e-8 and result['minimum_prefix'] >= -budget-1e-8
    assert all(row['spent_loss']+row['reserved'] <= budget+1e-8 for row in result['ledger'])
    assert len(acts) == result['admissions']
    assert sum(row['local_net'] > 0 for row in acts) == result['beneficial']
    assert sum(row['local_net'] < 0 for row in acts) == result['harmful']
    assert sum(row['local_net'] == 0 for row in acts) == result['zero']


def main():
    protocol = load(ROOT/'protocol.json')
    for path, expected in protocol['source_hashes'].items():
        assert sha(path) == expected, path
    lock = load(ROOT/'rss348_selection_lock.json')
    for key, file in (('protocol_sha256', 'protocol.json'), ('selection_sha256', 'rss348_selection.json'),
                      ('trials_sha256', 'rss348_calibration_trials.json.gz')):
        assert lock[key] == sha(ROOT/file)
    metadata = load(PROJECT/'work/fusion_temporal_20261003/physical/data/rss348/cache_metadata.json')
    calibration_windows = math.ceil((metadata['split_boundaries']['ncal']-metadata['split_boundaries']['ntrain'])/32)
    development_windows = math.ceil((metadata['n']-metadata['split_boundaries']['ncal'])/32)
    calibration = load(ROOT/'rss348_calibration_trials.json.gz')
    selections = load(ROOT/'rss348_selection.json')
    cal_results, initial_ranks = [], 0
    for trial in calibration:
        cfg = trial['configuration']
        for guarded in trial['guarded']:
            guarded_rows(guarded, 130.)
            assert not any(row['action'] and row['k'] < calibration_windows//2 for row in guarded['rows'])
        near(float(np.mean([row['increment'] for row in trial['guarded']])), cfg['guarded_net'])
        near(sum(row['beneficial'] for row in trial['guarded']), cfg['beneficial'])
        near(sum(row['harmful'] for row in trial['guarded']), cfg['harmful'])
        if cfg['arm'] not in QUANTILE_ARMS:
            continue
        ranks = [row['cdf_rank'] for result in trial['results'] for row in result['rows']
                 if row['information_ready'] and row['maturity'] <= calibration_windows//2]
        assert ranks == cfg['fit_scores']
        initial = max(1e-4, min(cfg['beta_cap'], float(np.quantile(ranks, .1, method='lower')))) if ranks else 1e-4
        near(initial, cfg['initial'])
        initial_ranks += len(ranks)
        cal_results.extend(reconstruct(result, cfg, calibration_windows, True) for result in trial['results'])
    for arm in protocol['arms']:
        candidates = [trial['configuration'] for trial in calibration if trial['configuration']['arm'] == arm]
        assert len(candidates) == 9
        if arm in QUANTILE_ARMS:
            key = lambda cfg: (cfg['guarded_net'], -cfg['beta_cap'], cfg['bandwidth'])
        else:
            key = lambda cfg: (cfg['guarded_net'], cfg['q_floor'], -cfg['prior_sd'] if arm.startswith('legacy_') else cfg['bandwidth'])
        assert max(candidates, key=key) == selections['selected'][arm]
    development = load(ROOT/'rss348_development_results.json.gz')
    for guarded in development['guarded']:
        guarded_rows(guarded, guarded['budget'])
    dev_results = [reconstruct(trial['results'][arm], selections['selected'][arm], development_windows, False)
                   for trial in development['trials'] for arm in QUANTILE_ARMS]
    summary = load(ROOT/'rss348_development_summary.json')
    for arm, reported in summary['arms'].items():
        guarded = [row for row in development['guarded'] if row['arm'] == arm and row['budget'] == 130.]
        assert [row['increment'] for row in guarded] == reported['seed_increments']
        near(float(np.mean([row['increment'] for row in guarded])), reported['mean_increment'])
        for key in ('admissions', 'beneficial', 'harmful', 'zero', 'loss', 'refused'):
            near(sum(row[key] for row in guarded), reported[key])
    report = dict(passed=True, scope='retained previously inspected RSS development outputs and old RSS metadata only; no HARTH data or outcomes opened',
        source_hashes_and_selection_lock_verified=True, calibration_windows=calibration_windows,
        development_windows=development_windows, calibration=combine(cal_results), development=combine(dev_results),
        first_half_ready_fully_matured_fit_ranks=initial_ranks,
        all_63_quantile_configurations_initial_beta_reconstructed=True,
        all_10_arms_nine_configuration_guarded_selection_verified=True,
        actual_calibration_guarded_scores_reconstructed_from_rows=True,
        guarded_calibration_trajectories=sum(len(trial['guarded']) for trial in calibration),
        guarded_development_trajectories=len(development['guarded']),
        all_four_development_budget_ledgers_and_action_sums_verified=True,
        issuance_beta_and_every_delayed_callback_reconstructed=True,
        rejected_ready_callbacks_included_unready_callbacks_excluded=True,
        rank_covered_implies_quantile_covered_within_4e_minus_13=True,
        every_covered_row_obeys_complete_paid_lower_bound=True,
        all_guarded_B130_summaries_reconstructed=True,
        candidate=dict(original_CJ=summary['arms']['conditional_joint'], CJ_Q=summary['arms']['q_joint'],
            mean_return_difference=summary['arms']['q_joint']['mean_increment']-summary['arms']['conditional_joint']['mean_increment'],
            conclusion='CJ-Q did not improve original CJ on the previously inspected RSS development split; retained as failed development, not fresh-task evidence'),
        no_admitted_action_coverage_or_true_quantile_guarantee=True)
    path = HERE/'quantile_retained_report.json'
    path.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
