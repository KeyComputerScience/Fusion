"""Independent density integration of the executed CJ-Q CDF API; synthetic only."""
from pathlib import Path
import importlib.util,json,math,sys,hashlib
import numpy as np
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
p=ROOT.parent/'design_quantile/quantile.py'
sp=importlib.util.spec_from_file_location('actual_quantile_api',p);q=importlib.util.module_from_spec(sp);sp.loader.exec_module(q)
x,w=np.polynomial.legendre.leggauss(16)
def integrate(fun,lo,hi,bins=256):
    edges=np.linspace(lo,hi,bins+1);half=(edges[1:]-edges[:-1])/2
    pts=((edges[1:]+edges[:-1])/2)[:,None]+half[:,None]*x
    return float(np.sum(fun(pts.ravel()).reshape(bins,16)*half[:,None]*w))
h=np.array([.18,-.04]);alpha=np.array([.3,.7]);loc=np.array([[-.11,.08],[.09,-.03]])
V=np.array([[[.018,.006],[.006,.03]],[[.025,-.004],[-.004,.012]]])
def joint(u):
    z=h[None,:]-u[:,None];f=np.zeros(len(u))
    for a,l,s in zip(alpha,loc,V):
        r=z-l;iv=np.linalg.inv(s)
        f+=a*np.exp(-.5*np.einsum('is,st,it->i',r,iv,r))/(2*np.pi*np.sqrt(np.linalg.det(s)))
    return f
def product(u):
    z=h[None,:]-u[:,None];f=np.ones(len(u))
    for s in range(2):
        one=np.zeros(len(u))
        for a,l,v in zip(alpha,loc[:,s],V[:,s,s]):one+=a*np.exp(-.5*(z[:,s]-l)**2/v)/np.sqrt(2*np.pi*v)
        f*=one
    return f
checks=[]
for name,law,fn in [('joint',q.AnalyticLaw(h,alpha,loc,V),joint),('exact_product',q.QuadratureLaw(h,alpha,loc,V),product)]:
    Z=integrate(fn,-1,1);errors=[];widths=[]
    for u in np.linspace(-.6,.6,19):errors.append(abs(law.cdf(u)-integrate(fn,-1,u)/Z))
    for beta in (1e-4,.01,.1,.25,.5):
        b=law.quantile(beta);widths.append(b['width']);assert b['cdf_lower']<=beta+1e-12<=b['cdf_upper']+2e-12
        assert abs(integrate(fn,-1,b['value'])/Z-beta)<1e-8
    assert max(errors)<1e-8
    checks.append(dict(law=name,max_CDF_error=max(errors),max_quantile_bracket_width=max(widths),refinement=law.error))
r=dict(passed=True,scope='synthetic API verification; no physical performance claim',source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),checks=checks)
(ROOT/'actual_api_report.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
