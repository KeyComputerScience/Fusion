"""Declared CJ-Q pilot; guarded calibration selection, all outcomes retained."""
from pathlib import Path
import argparse,datetime,hashlib,json,sys
sys.dont_write_bytecode=True
import numpy as np
import quantile as api
ROOT=Path(__file__).resolve().parent;PROJECT=ROOT.parents[2];c=api.c
TASKS=('rss348',);SDS=(.05,.1,.2)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
dump=c.dump;load=c.load

def freeze():
    assert not (ROOT/'protocol.json').exists();c.verify()
    sources=[Path(__file__),ROOT/'quantile.py',api.FROZEN/'run_conditional.py',api.FROZEN/'copula_control.py',
        c.PARENT,c.parent.FACTOR,c.parent.parent.MATRIX_SOURCE,c.parent.CORE,c.parent.ADAPTER]
    engine,recovery,guard,*_=api.binding();sources += [Path(m.__file__) for m in (engine,recovery,guard)]
    data=[PROJECT/'work/fusion_temporal_20261003/physical/data/rss348/cache_metadata.json',
        PROJECT/'work/fusion_temporal_20261003/physical/data/rss348/cached_dataset.npz']
    dump(ROOT/'protocol.json',dict(utc=now(),source_hashes={str(p):sha(p) for p in sources},data_hashes={str(p):sha(p) for p in data},
        tasks=TASKS,arms=api.ARMS,method='CJ-Q original complete-target posterior quantile',
        innovation='original paired error law and disagreement conditioning unchanged; paid gate N*Q_beta(U|h)-5; no new law or ensemble',
        controls='same quantile decision/calibration for exact-marginal product, full moment-matched Gaussian, Gaussian copula retaining each marginal/full dependence matrix, diagP paired innovation, original factorized and sandwich laws',
        initial_beta='min(cap, lower empirical10th percentile ready fullymatured first-half posteriorCDF(actualU)); clamp>=1e-4; emptyfit1e-4',
        beta_update='ready issued origins only; at complete maturity beta=clip(beta+.05*(.1-1{issuedCDF(Uactual)<issuedbeta}),1e-4,cap); saved issued law rank and threshold',
        grids=dict(quantile=dict(bandwidth=c.BANDWIDTHS,beta_cap=api.CAPS,configurations=9),
            originalCJ=dict(bandwidth=c.BANDWIDTHS,q_floor=c.FLOORS,configurations=9),
            legacy=dict(prior_sd=SDS,q_floor=c.FLOORS,configurations=9)),
        selection='maximize ACTUAL secondhalf Fixed130/B130 guarded calibration increment; ties smaller beta_cap then larger bandwidth; mean/std controls ties larger qfloor then larger bandwidth; legacy smaller prior_sd',
        calibration_seeds={'rss348':[87001,87002,87003]},development_seeds={'rss348':list(range(88001,88006))},
        execution=dict(reserve=130.,primary_budget=130.,budget_diagnostics=[0.,110.,130.,260.]),
        readiness='original nonempty mature eligible error blocks; unready origin logs its raw posterior quantile but cannot propose paid action',
        quantile_numerics='analytic truncated mixture CDF or adaptive8point compositeGL bins with prefix and partial-binCDF; refinement probes CDF and quantiles; lower bisection bracket issued, all widths retained',
        logger='gain=NQ,sd=1,q_issued=0,standardized_score=NQ-gross; beta and CDF rank distinct fields; q_updates empty and beta_updates explicit',
        bounded_target='U=complete gross/N in[-1,1], original declared uniform working prior; fitted density not proved physical sampling law',
        evidence_scope='RSS previously inspected test split is development only; third/last declared candidate after failed CJ-R/CJ-T; no fresh physical raw read',
        mandatory='all nine configs perarm, negative outcomes, seed trajectories, action rows and actualcoverage retained; no further tuning based on development results',
        limitations=['delayed all-origin calibration identity does not imply admitted-action conditional coverage',
            'lower quantile under fitted working law is not a guaranteed true quantile',
            'quadrature refinement is numerical diagnostic, not rigorous error certificate',
            'same traces with five delay schedules are not five independent physical sites',
            'pathwise service loss budget is shared; profit and superiority not guaranteed'],runtime=dict(python=sys.version,numpy=np.__version__)))

def verify():
    p=load(ROOT/'protocol.json')
    for field in ('source_hashes','data_hashes'):
        for f,w in p[field].items():assert sha(f)==w,f
    return p
def prepared(task):
    engine,recovery,guard,source,cfg,study,service,fork=api.binding();cfg.update(prior_sd=.1,threshold=0.)
    data,pre=c.parent.task_data(task,cfg,engine,source,study)
    return engine,recovery,guard,cfg,service,fork,data,pre
def configs(arm,cfg):
    if arm in api.NEW_ARMS:return [dict(cfg,slice_bandwidth=b,beta_cap=cap) for b in c.BANDWIDTHS for cap in api.CAPS]
    if arm.startswith('legacy_'):return [dict(cfg,slice_bandwidth=1.,prior_sd=sd,q_floor=floor) for sd in SDS for floor in c.FLOORS]
    return [dict(cfg,slice_bandwidth=b,q_floor=floor) for b in c.BANDWIDTHS for floor in c.FLOORS]
def selected_cfg(cfg,x):
    out=dict(cfg,slice_bandwidth=x['bandwidth'],prior_sd=x['prior_sd'],q_floor=x['q_floor'])
    if x['beta_cap'] is not None:out['beta_cap']=x['beta_cap']
    return out
def guarded(guard,service,ev,pre,cfg,rows,B=130.):
    gg=guard.replay(rows,len(ev),B,'gross_loss',{x['k']:130. for x in rows})
    actual=service(ev,pre,gg['rows'],cfg);reference=service(ev,pre,[],cfg);prefix=guard.reconstruct_prefix_increment(ev,gg['rows'],cfg)
    acts=[x for x in gg['rows'] if x['action']];inc=actual['net']-reference['net']
    err=max(abs(inc-sum(x['local_net'] for x in acts)),abs(inc-prefix['final']),abs(inc-gg['final_settled_increment']))
    loss=sum(max(0.,-x['local_net']) for x in acts)
    assert err<1e-8 and loss<=B+1e-8 and prefix['minimum']>=-B-1e-8
    assert all(x['spent_loss']+x['reserved']<=B+1e-8 for x in gg['ledger'])
    return dict(increment=inc,net=actual['net'],loss=loss,minimum_prefix=prefix['minimum'],service_error=err,
        admissions=len(acts),beneficial=sum(x['local_net']>0 for x in acts),harmful=sum(x['local_net']<0 for x in acts),
        zero=sum(x['local_net']==0 for x in acts),coverage=[sum(x['lower_covered'] for x in acts),len(acts)],
        rank_coverage=[sum(x.get('rank_covered',x['lower_covered']) for x in acts),len(acts)],
        optimistic_excess=sum(x['posterior_or_block_sd']*max(x['standardized_score']-x['q_issued'],0.) for x in acts),
        actual_lower_deficit=sum(max(x['gate_score']-x['local_net'],0.) for x in acts),
        refused=sum(x['proposed_action'] and not x['action'] for x in gg['rows']),rows=gg['rows'],ledger=gg['ledger'])
def calibrate(tasks):
    p=verify()
    for task in tasks:
        assert not (ROOT/(task+'_selection.json')).exists()
        engine,recovery,guard,cfg0,service,fork,data,pre=prepared(task);seeds=p['calibration_seeds'][task]
        worlds=[engine.world(pre['cal_x'],pre['cal_y'],pre['cal_timestamp'],pre,s,cfg0) for s in seeds]
        bases=[engine.precompute(ev,pre,cfg0) for ev in worlds];streams={};trials=[];grid=[]
        for arm in api.ARMS:
            for cfg in configs(arm,cfg0):
                ss=[]
                for i,ev in enumerate(worlds):
                    key=(i,)+api.stream_key(cfg)
                    if key not in streams:streams[key]=api.core.augment(ev,pre,bases[i],cfg)
                    ss.append(streams[key])
                initial,fit=api.initial(ss,pre,cfg,arm);rr=[api.run(engine,s,pre,cfg,arm,initial,True) for s in ss]
                gr=[guarded(guard,service,ev,pre,cfg,r['rows']) for ev,r in zip(worlds,rr)]
                x=dict(arm=arm,bandwidth=cfg['slice_bandwidth'],prior_sd=cfg['prior_sd'],q_floor=cfg.get('q_floor',0.),
                    beta_cap=cfg.get('beta_cap'),initial=initial,guarded_net=float(np.mean([g['increment'] for g in gr])),
                    unguarded_net=float(np.mean([r['selection_net'] for r in rr])),fit_scores=fit,
                    beneficial=sum(g['beneficial'] for g in gr),harmful=sum(g['harmful'] for g in gr))
                grid.append(x);trials.append(dict(configuration=x,seeds=seeds,results=rr,guarded=gr))
            print('CAL',task,arm,flush=True)
        def priority(x):
            if x['arm'] in api.NEW_ARMS:return x['guarded_net'],-x['beta_cap'],x['bandwidth']
            return x['guarded_net'],x['q_floor'],-x['prior_sd'] if x['arm'].startswith('legacy_') else x['bandwidth']
        selected={a:max((x for x in grid if x['arm']==a),key=priority) for a in api.ARMS}
        dump(ROOT/(task+'_calibration_trials.json.gz'),trials);dump(ROOT/(task+'_selection.json'),dict(selected=selected,grid=grid,data_hashes=data['hashes']))
        dump(ROOT/(task+'_selection_lock.json'),dict(utc=now(),protocol_sha256=sha(ROOT/'protocol.json'),selection_sha256=sha(ROOT/(task+'_selection.json')),trials_sha256=sha(ROOT/(task+'_calibration_trials.json.gz'))))
        print('SELECT',task,{a:(x['guarded_net'],x['bandwidth'],x['beta_cap'],x['initial']) for a,x in selected.items()},flush=True)
def summarize(records):
    out={}
    for arm in api.ARMS:
        rr=[x for x in records if x['arm']==arm and x['budget']==130.];incs=[x['increment'] for x in rr]
        out[arm]=dict(mean_increment=float(np.mean(incs)),seed_increments=incs,admissions=sum(x['admissions'] for x in rr),
            beneficial=sum(x['beneficial'] for x in rr),harmful=sum(x['harmful'] for x in rr),zero=sum(x['zero'] for x in rr),
            loss=sum(x['loss'] for x in rr),coverage=[sum(x['coverage'][0] for x in rr),sum(x['coverage'][1] for x in rr)],
            rank_coverage=[sum(x['rank_coverage'][0] for x in rr),sum(x['rank_coverage'][1] for x in rr)],
            optimistic_excess=sum(x['optimistic_excess'] for x in rr),actual_lower_deficit=sum(x['actual_lower_deficit'] for x in rr),refused=sum(x['refused'] for x in rr))
    return out
def test(tasks):
    p=verify()
    for task in tasks:
        lock=load(ROOT/(task+'_selection_lock.json'))
        assert lock['protocol_sha256']==sha(ROOT/'protocol.json') and lock['selection_sha256']==sha(ROOT/(task+'_selection.json'))
        assert lock['trials_sha256']==sha(ROOT/(task+'_calibration_trials.json.gz'))
        assert not (ROOT/(task+'_development_results.json.gz')).exists()
        engine,recovery,guard,cfg0,service,fork,data,pre=prepared(task);selected=load(ROOT/(task+'_selection.json'))['selected']
        trials=[];records=[];fixed=[];poisons=0;maxquad=0.;maxwidth=0.
        for seed in p['development_seeds'][task]:
            ev=engine.world(pre['test_x'],pre['test_y'],pre['test_timestamp'],pre,seed,cfg0)
            base=engine.precompute(ev,pre,cfg0);streams={};results={};checks={}
            for arm in api.ARMS:
                x=selected[arm];cfg=selected_cfg(cfg0,x);key=api.stream_key(cfg)
                if key not in streams:streams[key]=api.core.augment(ev,pre,base,cfg)
                stream=streams[key];r=api.run(engine,stream,pre,cfg,arm,x['initial'])
                checks[arm]=recovery.execute_check(ev,pre,cfg,r,service,fork);assert checks[arm]['passed'];results[arm]=r
                for d,row in zip(stream['decisions'],r['rows']):
                    level=row['beta_issued'] if arm in api.NEW_ARMS else row['q_issued']
                    a=api.forecast(d,pre,cfg,arm,level);b=api.forecast(dict(d,truegross=1e50,localnet=-1e50),pre,cfg,arm,level)
                    assert a[2:4]==b[2:4];poisons+=1;maxquad=max(maxquad,row.get('quadrature_error',0.));maxwidth=max(maxwidth,row.get('quantile_bracket_width',0.))
                    if arm in api.NEW_ARMS:
                        assert row['quantile_cdf_lower']<=level+1e-12 and row['quantile_cdf_upper']>=level-1e-12
                        assert abs(row['gain']-d['N']*row['quantile'])<1e-10
                        if row['rank_covered']:assert row['lower_covered']
                        if row['lower_covered']:assert row['local_net']>=row['paid_lower_bound']-1e-8
                for B in p['execution']['budget_diagnostics']:
                    records.append(dict(task=task,seed=seed,arm=arm,budget=B,**guarded(guard,service,ev,pre,cfg,r['rows'],B)))
            x=selected['q_joint'];cfg=selected_cfg(cfg0,x);stream=streams[api.stream_key(cfg)]
            for d,row in zip(stream['decisions'],results['q_joint']['rows']):
                preds={}
                for arm in api.NEW_ARMS:
                    _,_,F,S,_,extra=api.forecast(d,pre,cfg,arm,row['beta_issued'])
                    preds[arm]=dict(F=F,score=F-5,quantile=extra['quantile'],action=bool(extra['information_ready'] and F-5>0))
                fixed.append(dict(seed=seed,k=d['k'],D=d['localnet'],beta=row['beta_issued'],predictions=preds))
            trials.append(dict(seed=seed,reference=service(ev,pre,[],cfg0),results=results,checks=checks))
            print('DEV',task,seed,{a:next(x['increment'] for x in reversed(records) if x['arm']==a and x['budget']==130.) for a in api.ARMS},flush=True)
        comparison={}
        for arm in api.NEW_ARMS[1:]:
            changed=[x for x in fixed if x['predictions']['q_joint']['action']!=x['predictions'][arm]['action']]
            comparison[arm]=dict(changed=len(changed),joint_only=sum(x['predictions']['q_joint']['action'] for x in changed),
                utility_difference=sum((int(x['predictions']['q_joint']['action'])-int(x['predictions'][arm]['action']))*x['D'] for x in changed))
        summary=summarize(records);report=dict(task=task,selected=selected,arms=summary,fixed_state=comparison,
            max_service_error=max(x['service_error'] for x in records),current_truth_poison_checks=poisons,
            max_quadrature_refinement=maxquad,max_quantile_bracket_width=maxwidth,development_only=True)
        dump(ROOT/(task+'_development_results.json.gz'),dict(trials=trials,guarded=records,fixed=fixed));dump(ROOT/(task+'_development_summary.json'),report)
        print('SUMMARY',task,{a:(x['mean_increment'],x['beneficial'],x['harmful']) for a,x in summary.items()},flush=True)
    verify()
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('phase',choices=['freeze','calibrate','test']);ap.add_argument('--tasks',nargs='+',default=TASKS);args=ap.parse_args()
    {'freeze':freeze,'calibrate':lambda:calibrate(tuple(args.tasks)),'test':lambda:test(tuple(args.tasks))}[args.phase]()
