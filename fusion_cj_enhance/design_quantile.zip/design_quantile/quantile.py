"""CJ-Q: original bounded complete-target law with a delayed quantile gate.

The error law, raw relevance weights, completion and source models are the
immutable original CJ. Only its paid decision functional/calibration changes.
"""
from pathlib import Path
import importlib.util,math,sys
sys.dont_write_bytecode=True
import numpy as np
ROOT=Path(__file__).resolve().parent;PROJECT=ROOT.parents[2]
FROZEN=PROJECT/'work/fusion_conditional_20261004'
sp=importlib.util.spec_from_file_location('cjq_frozen_copula',FROZEN/'copula_control.py')
cp=importlib.util.module_from_spec(sp);sp.loader.exec_module(cp)
c=cp.c;core=c.core;matrix=c.parent.parent.matrix
ARM_MAP=dict(q_joint='conditional_joint',q_product='conditional_marginal',
    q_factorized='conditional_factorized',q_gaussian='conditional_gaussian',
    q_sandwich='conditional_sandwich',q_copula='conditional_copula',q_joint_diagP='conditional_joint_diagP')
NEW_ARMS=tuple(ARM_MAP)
ARMS=('conditional_joint',)+NEW_ARMS+('legacy_factorized','legacy_sandwich')
CAPS=(.1,.25,.5);BETA_MIN=1e-4;STEP=.05;TARGET=.1

def interval_normal(lo,hi):
    return c.cdf(hi)-c.cdf(lo) if lo<0 else c.cdf(-lo)-c.cdf(-hi)

class AnalyticLaw:
    def __init__(self,h,alpha,locations,covariances):
        means=[];variances=[];logs=[];zs=[];one=np.ones(len(h))
        for a,loc,S in zip(alpha,locations,covariances):
            inv=np.linalg.solve(S,np.eye(len(h)));v=1/float(one@inv@one);r=h-loc
            mean=v*float(one@inv@r);_,ld=np.linalg.slogdet(S)
            ev=-.5*(len(h)*c.LOG2PI+ld+float(r@inv@r)-mean**2/v)+.5*math.log(2*math.pi*v)
            sd=math.sqrt(v);Z=interval_normal((-1-mean)/sd,(1-mean)/sd)
            if Z<=1e-280:continue
            means.append(mean);variances.append(v);zs.append(Z);logs.append(math.log(float(a))+ev+math.log(Z))
        assert logs
        self.means=np.asarray(means);self.variances=np.asarray(variances);self.zs=np.asarray(zs)
        self.weights=np.exp(np.asarray(logs)-c.logsumexp(np.asarray(logs)))
        self.summary=c.joint_posterior(h,alpha,locations,covariances)
        self.error=0.;self.bins=0
    def cdf(self,u):
        if u<=-1:return 0.
        if u>=1:return 1.
        terms=[]
        for mean,var,Z in zip(self.means,self.variances,self.zs):
            sd=math.sqrt(var);z=interval_normal((-1-mean)/sd,(u-mean)/sd)
            terms.append(min(1.,max(0.,z/Z)))
        return min(1.,max(0.,float(self.weights@terms)))
    def quantile(self,beta):
        assert 0.<beta<1.
        lo,hi=-1.,1.
        for _ in range(54):
            mid=(lo+hi)/2
            if self.cdf(mid)<=beta:lo=mid
            else:hi=mid
        return dict(value=lo,upper=hi,cdf_lower=self.cdf(lo),cdf_upper=self.cdf(hi),width=hi-lo)

class QuadratureLaw:
    """Same continuous line density; prefix bins plus partial-bin integration.

    Coarse/fine CDF and quantile comparisons are diagnostics, not certified
    analytic error bounds. All quadrature failures are surfaced before use.
    """
    def __init__(self,h,alpha,locations,covariances,C=None):
        self.h=np.asarray(h);self.alpha=np.asarray(alpha);self.locations=np.asarray(locations)
        self.variances=np.diagonal(covariances,axis1=1,axis2=2);self.copula=C is not None
        if self.copula:
            corr=cp.dependence(C);self.correction=np.linalg.solve(corr,np.eye(len(h)))-np.eye(len(h))
            self.ld=np.linalg.slogdet(corr)[1]
        minsd=math.sqrt(float(1/np.sum(1/self.variances.min(0))))
        bins=max(32,int(math.ceil(1/minsd)));self._build(bins)
        probes=np.linspace(-1,1,17);levels=(1e-4,.01,.05,.1,.25,.5)
        previous=[self.cdf(x) for x in probes]+[self.quantile(x)['value'] for x in levels]
        self.error=1.
        for step in range(6):
            bins*=2;self._build(bins)
            current=[self.cdf(x) for x in probes]+[self.quantile(x)['value'] for x in levels]
            self.error=float(np.max(np.abs(np.asarray(current)-previous)))
            if self.error<1e-9:break
            previous=current
        assert self.error<1e-7,('quantile quadrature',self.error,bins)
        self.summary=dict(mean=self.mean,variance=self.variance,component_count=len(alpha),
            posterior_effective_components=None,quadrature_error=self.error,
            quadrature_nodes=8*bins,quadrature_refinements=step+1)
    def logdensity(self,u):
        u=np.asarray(u);out=np.zeros(len(u));latent=[]
        for s in range(len(self.h)):
            r=self.h[s]-u[:,None]-self.locations[None,:,s];var=self.variances[:,s][None,:]
            log=np.log(self.alpha)[None,:]-.5*(c.LOG2PI+np.log(var)+r*r/var)
            out+=c.logsumexp(log,axis=1)
            if self.copula:latent.append(cp.ndtri(cp.ndtr(r/np.sqrt(var))@self.alpha))
        if self.copula:
            eta=np.asarray(latent).T
            out+=-.5*self.ld-.5*np.einsum('is,st,it->i',eta,self.correction,eta)
        return out
    def _build(self,bins):
        self.bins=bins;self.edges=np.linspace(-1.,1.,bins+1)
        u,qw=c.quadrature(bins);ld=self.logdensity(u);self.shift=float(ld.max())
        terms=np.exp(ld-self.shift)*qw;self.total=float(terms.sum())
        masses=terms.reshape(bins,8).sum(1);self.prefix=np.r_[0.,np.cumsum(masses)]/self.total;self.prefix[-1]=1.
        prob=terms/self.total;self.mean=float(prob@u);self.variance=float(prob@(u-self.mean)**2)
    def cdf(self,u):
        if u<=-1:return 0.
        if u>=1:return 1.
        i=min(self.bins-1,int((u+1)*self.bins/2));a=self.edges[i]
        half=(u-a)/2;points=(u+a)/2+half*c.QUAD_X
        mass=float(np.sum(np.exp(self.logdensity(points)-self.shift)*half*c.QUAD_W))/self.total
        return float(np.clip(self.prefix[i]+mass,self.prefix[i],self.prefix[i+1]))
    def quantile(self,beta):
        assert 0.<beta<1.
        i=min(self.bins-1,max(0,int(np.searchsorted(self.prefix,beta,side='right')-1)))
        lo,hi=float(self.edges[i]),float(self.edges[i+1])
        for _ in range(38):
            mid=(lo+hi)/2
            if self.cdf(mid)<=beta:lo=mid
            else:hi=mid
        return dict(value=lo,upper=hi,cdf_lower=self.cdf(lo),cdf_upper=self.cdf(hi),width=hi-lo)

def state(arrived,current,pre,cfg):
    mm=c.parent.cumulant_state(arrived,current,pre,cfg);h=current['h'];ids=current['ids']
    a,l,V,mu,C,jitter=c.law(mm,pre,ids,cfg);fa,fl,fV,_,_,_=c.law(mm,pre,ids,cfg,True)
    laws=dict(q_joint=AnalyticLaw(h,a,l,V),q_product=QuadratureLaw(h,a,l,V),
        q_factorized=QuadratureLaw(h,fa,fl,fV),q_gaussian=AnalyticLaw(h,np.ones(1),mu[None],C[None]),
        q_sandwich=AnalyticLaw(h,np.ones(1),mu[None],(mm['paired_atoms']['C']+mm['sandwich_P']+jitter)[None]),
        q_copula=QuadratureLaw(h,a,l,V,C),q_joint_diagP=AnalyticLaw(h,a,l,V-mm['P']+np.diag(np.diag(mm['P']))))
    inv=np.linalg.solve(C,np.eye(len(h)));one=np.ones(len(h))
    mm.update(quantile_laws=laws,conditional={ARM_MAP[a]:law.summary for a,law in laws.items()},
        current_source_rate=h.tolist(),current_disagreement=(h-h.mean()).tolist(),
        line_gls_untruncated_mean=float(one@inv@(h-mu)/(one@inv@one)),current_label_access=False,
        conditioning_inputs=dict(h=h.tolist(),source_ids=ids.tolist(),target_bounds=[-1.,1.]))
    return mm

def forecast(d,pre,cfg,arm,level):
    if arm=='legacy_factorized':return c.parent.parent.factorized_forecast(d,pre,cfg,'factorized_information',level)
    if arm=='legacy_sandwich':return matrix.matrix_forecast(d,pre,cfg,'block_sandwich',level)
    if arm not in NEW_ARMS:return c.conditional_forecast(d,pre,cfg,arm,level)
    law=d['temporal']['quantile_laws'][arm];q=law.quantile(level);quality=pre['q'][d['ids']]
    w=core.capped(quality/quality.sum(),max(cfg['cap'],1/len(quality)))
    F=float(d['N']*q['value']);S=1.
    return w,dict(converged=True,kkt=0.,primal=0.,iterations=0),F,S,(F-d['truegross'])/S,dict(
        information_ready=bool(d['temporal']['eligible']),quantile=q['value'],quantile_upper=q['upper'],
        quantile_bracket_width=q['width'],quantile_cdf_lower=q['cdf_lower'],quantile_cdf_upper=q['cdf_upper'],
        beta_issued=float(level),conditional_mean=law.summary['mean'],conditional_variance=law.summary['variance'],
        raw_optimized_gain=float(d['N']*law.summary['mean']),posterior_norm=0.,entropy=0.,
        source_weights_redundant=True,slice_bandwidth=cfg['slice_bandwidth'],quadrature_error=law.error,
        quantile_gate=True,original_posterior_sd=float(d['N']*math.sqrt(law.summary['variance']+cfg['norm_floor']**2)))

def initial_beta(streams,pre,cfg,arm):
    ranks=[]
    for stream in streams:
        for d in stream['decisions']:
            if d['maturity']<=stream['windows']//2 and bool(d['temporal']['eligible']):
                ranks.append(d['temporal']['quantile_laws'][arm].cdf(d['truegross']/d['N']))
    beta=min(cfg['beta_cap'],float(np.quantile(ranks,.1,method='lower'))) if ranks else BETA_MIN
    return max(BETA_MIN,beta),ranks

def run_quantile(engine,stream,pre,cfg,arm,beta_initial,selection=False):
    beta=float(beta_initial);pending=[];updates=[];rows=[];actions=[];regsum=0.;violations=0
    net=stream['basegross']-stream['commonfees'];gross=stream['basegross'];fees=stream['commonfees']
    drops=stream['commondrops'];correct=stream['basecorrect'];boundary=stream['windows']//2 if selection else 0;select_net=0.
    def release(now):
        nonlocal beta,pending,regsum,violations
        for due,origin,issued,rank,Q in sorted(pending,key=lambda x:x[0]):
            if due<=now:
                v=int(rank<issued);proposal=beta+STEP*(TARGET-v);new=float(np.clip(proposal,BETA_MIN,cfg['beta_cap']))
                regulator=new-proposal;regsum+=regulator;violations+=v
                updates.append(dict(maturity=due,issued_index=origin,update_index=now,beta_issued=issued,
                    cdf_rank=rank,quantile_issued=Q,violation=v,beta_before=beta,beta_after=new,regulator=regulator))
                beta=new
        pending=[x for x in pending if x[0]>now]
    for d in stream['decisions']:
        k=d['k'];release(k);w,cert,F,S,standardized,extra=forecast(d,pre,cfg,arm,beta)
        paid=F-5.-cfg['threshold'];proposal=bool(extra['information_ready'] and paid>0);action=proposal and k>=boundary
        if action:
            net+=d['localnet'];gross+=d['grossdifference'];fees+=3.;drops+=cfg['deploy_drop'];correct+=d['accdifference']
            select_net+=d['localnet'] if k>=boundary else 0.
        U=d['truegross']/d['N'];rank=d['temporal']['quantile_laws'][arm].cdf(U)
        mm=d['temporal'];row=dict(k=k,action=bool(action),weights=w.tolist(),gain=F,posterior_or_block_sd=S,
            q_issued=0.,penalty=0.,gate_score=paid,standardized_score=standardized,truegross=d['truegross'],
            local_net=d['localnet'],disagreement=d['disagreement'],maturity=d['maturity'],
            lower_covered=bool(U>=extra['quantile']),cdf_rank=rank,rank_covered=bool(rank>=beta),
            future_accuracy_gain=d['future'],blocks=d['blocks'],mass=d['mass'],scale=d['scale'],
            solver_converged=True,kkt=0.,arm=arm,**extra,joint_mu=mm['mu'].tolist(),joint_R=mm['R'].tolist(),
            joint_P=mm['P'].tolist(),precision_non_scalar=mm['non_scalar'],active_source_ids=d['ids'].tolist(),
            eligible=mm['eligible'],partial_blocks=mm['partial_blocks'],point_value_opportunity=bool(F-5>0),
            pre_gate_proposal=proposal,complete_target=U,paid_lower_bound=F-5.)
        assert all(x['maturity']<=k for x in mm['eligible'])
        rows.append(row);actions.append(bool(action))
        if extra['information_ready'] and (not selection or k>=boundary):pending.append((d['maturity'],k,beta,rank,extra['quantile']))
    release(stream['windows']);count=len(updates)
    identity=violations-(TARGET*count+(beta_initial-beta+regsum)/STEP)
    assert abs(identity)<1e-8
    acts=[x for x in rows if x['action']];selected=[x for x in rows if x['k']>=boundary];informative=[x for x in selected if x['disagreement']>0]
    return dict(net=net,gross=gross,fees=fees,drops=drops,accuracy=correct/stream['n'],deployments=len(acts),
        actions=actions,rows=rows,q_updates=[],q_initial=0.,q_final=0.,beta_updates=updates,beta_initial=beta_initial,
        beta_final=beta,clip_regulator_sum=regsum,calibration_updates=count,miscoverage=violations/count if count else None,
        calibration_identity_error=identity,coverage=float(np.mean([x['lower_covered'] for x in selected])) if selected else None,
        informative_coverage=float(np.mean([x['lower_covered'] for x in informative])) if informative else None,
        informative_episodes=len(informative),beneficial=sum(x['local_net']>0 for x in acts),
        harmful=sum(x['local_net']<0 for x in acts),zero=sum(x['local_net']==0 for x in acts),solver_failures=0,max_kkt=0.,
        selection_net=select_net,closed_loop_identity_error=net-(stream['basegross']-stream['commonfees']+sum(x['local_net'] for x in acts)))

def run(engine,stream,pre,cfg,arm,initial,selection=False):
    return run_quantile(engine,stream,pre,cfg,arm,initial,selection) if arm in NEW_ARMS else core.run(engine,stream,pre,cfg,arm,initial,selection)
def initial(streams,pre,cfg,arm):
    return initial_beta(streams,pre,cfg,arm) if arm in NEW_ARMS else core.initial_q(streams,pre,cfg,arm)
def configure(cfg,arm):return dict(cfg)
def stream_key(cfg):return (cfg['slice_bandwidth'],cfg['prior_sd'])
def binding():return c.parent.binding()
core.state=state;core.forecast=forecast
