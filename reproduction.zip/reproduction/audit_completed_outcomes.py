"""Independent completed-record audit; standard library, no model/data import.

Both final completion records are required before any outcome file is opened.
This checks saved immutable complete-fork returns and issued/service records;
it does not rerun source fitting or reopen physical feature/label arrays.
"""
from pathlib import Path
import argparse
import collections
import gzip
import hashlib
import json
import math

DEFAULT=Path(__file__).resolve().parents[1]/'physical'
TOL=1e-8


def load(path):
    if str(path).endswith('.gz'):
        with gzip.open(path,'rt') as handle:return json.load(handle)
    return json.loads(Path(path).read_text())


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def near(a,b,tol=TOL):
    assert math.isfinite(a) and math.isfinite(b) and abs(a-b)<=tol,(a,b)


def indexed(rows):
    answer={r['k']:r for r in rows};assert len(answer)==len(rows)
    assert list(answer)==sorted(answer)
    return answer


def four_terms(primary,control):
    assert primary.keys()==control.keys()
    terms=dict(kept_gain=0.,missed_gain=0.,avoided_loss=0.,incurred_loss=0.,
        changed_actions=0,changed_positive=0,changed_negative=0,changed_zero=0)
    direct=0.
    for k,a in primary.items():
        b=control[k];near(a['local_net'],b['local_net'],1e-10)
        if 'truegross' in a and 'truegross' in b:near(a['truegross'],b['truegross'],1e-10)
        direction=int(a['action'])-int(b['action']);D=a['local_net'];direct+=direction*D
        if not direction:continue
        terms['changed_actions']+=1
        terms['changed_positive' if D>0 else 'changed_negative' if D<0 else 'changed_zero']+=1
        if direction>0:terms['kept_gain']+=max(D,0.);terms['incurred_loss']+=max(-D,0.)
        else:terms['missed_gain']+=max(D,0.);terms['avoided_loss']+=max(-D,0.)
    terms['direct_difference']=direct
    near(direct,terms['kept_gain']-terms['missed_gain']+terms['avoided_loss']-terms['incurred_loss'])
    return terms


def row_metrics(rows):
    acts=[r for r in rows if r['action']]
    S_excess=[];target_error=0.;certificate=0.
    for row in rows:
        F,S,q,T=row['gain'],row['posterior_or_block_sd'],row['q_issued'],row['standardized_score']
        assert S>0 and q>=0 and row['maturity']>row['k']
        near(T,(F-row['truegross'])/S,1e-10)
        assert row['lower_covered']==(T<=q)
        delta=row['local_net']-row['truegross']+5
        assert -TOL<=delta<=2+TOL
        identity=(F-q*S-5)-S*(T-q)+delta
        target_error=max(target_error,abs(identity-row['local_net']))
        near(identity,row['local_net'])
        excess=S*max(T-q,0.);near(excess,max(F-row['truegross']-q*S,0.))
        if row['action']:
            S_excess.append(excess);certificate+=F-q*S-5-excess
            if row['lower_covered']:assert row['local_net']>=F-q*S-5-TOL
    total=sum(r['local_net'] for r in acts);assert total>=certificate-TOL
    return dict(admissions=len(acts),beneficial=sum(r['local_net']>0 for r in acts),
        harmful=sum(r['local_net']<0 for r in acts),zero=sum(r['local_net']==0 for r in acts),
        covered=sum(r['lower_covered'] for r in acts),violations=sum(not r['lower_covered'] for r in acts),
        admitted_coverage=[sum(r['lower_covered'] for r in acts),len(acts)],
        coverage_rate=sum(r['lower_covered'] for r in acts)/len(acts) if acts else None,
        optimistic_excess=sum(S_excess),maximum_excess=max(S_excess,default=None),
        negative_loss=sum(max(-r['local_net'],0.) for r in acts),increment=total,
        return_certificate=certificate,certificate_slack=total-certificate,
        maximum_target_identity_error=target_error)


def audit_callbacks(result,q0,floor):
    rows=indexed(result['rows']);near(result['q_initial'],q0,1e-12)
    q=result['q_initial'];violations=0;regulators=0.;last=-1
    updates=result['q_updates']
    for update in updates:
        row=rows[update['issued_index']]
        assert row['k']<update['maturity']<=update['update_index']
        assert update['update_index']>=last;last=update['update_index']
        assert update['maturity']==row['maturity']
        for a,b in (('issued_q','q_issued'),('issued_std','posterior_or_block_sd'),('standardized_score','standardized_score')):
            near(update[a],row[b],1e-12)
        violation=int(row['standardized_score']>row['q_issued']);assert update['violation']==violation
        proposal=q+.05*(violation-.1);after=max(floor,proposal)
        near(q,update['q_before'],1e-12);near(after,update['q_after'],1e-12)
        near(after-proposal,update['regulator'],1e-12)
        q=after;violations+=violation;regulators+=update['regulator']
    near(q,result['q_final'],1e-12);assert len(updates)==result['calibration_updates']
    identity=violations-(.1*len(updates)+(q-result['q_initial']-regulators)/.05)
    near(identity,0.,1e-10);near(identity,result['calibration_identity_error'],1e-12)
    # Updates are released before issuance at a shared window index.
    q=result['q_initial'];i=0
    for row in rows.values():
        while i<len(updates) and updates[i]['update_index']<=row['k']:
            q=updates[i]['q_after'];i+=1
        near(q,row['q_issued'],1e-12)
    return dict(callbacks=len(updates),violations=violations,identity_error=identity)


def audit_guard(trajectory,original):
    rows=indexed(trajectory['rows']);issued=indexed(original['rows']);assert rows.keys()==issued.keys()
    B=trajectory['budget'];metrics=row_metrics(list(rows.values()))
    for k,row in rows.items():
        assert row['proposed_action']==issued[k]['action']
        assert not row['action'] or row['proposed_action']
        for name in ('gain','posterior_or_block_sd','q_issued','standardized_score','truegross','local_net','maturity','lower_covered'):
            assert row[name]==issued[k][name],name
    for name in ('admissions','beneficial','harmful'):assert metrics[name]==trajectory[name]
    if 'zero' in trajectory:assert metrics['zero']==trajectory['zero']
    if 'coverage' in trajectory:assert trajectory['coverage']==metrics['admitted_coverage']
    if 'covered_admitted' in trajectory:assert trajectory['covered_admitted']==metrics['covered']
    near(metrics['increment'],trajectory['increment'])
    near(metrics['negative_loss'],trajectory.get('negative_loss',trajectory.get('loss')))
    near(metrics['optimistic_excess'],trajectory['optimistic_excess'])
    assert metrics['negative_loss']<=B+TOL and trajectory['minimum_prefix']>=-B-TOL
    assert trajectory['refused']==sum(r['proposed_action'] and not r['action'] for r in rows.values())
    pending={};spent=settled=0.;last=-1
    for log in trajectory['ledger']:
        assert log['k']>=last;last=log['k']
        for callback in log['arrived']:
            origin=callback['origin'];assert origin in pending
            assert callback['maturity']<=log['k'] and callback['maturity']==rows[origin]['maturity']
            near(callback['increment'],rows[origin]['local_net'])
            assert callback['increment']>=-pending.pop(origin)-TOL
            spent+=max(-callback['increment'],0.);settled+=callback['increment']
        reserved=sum(pending.values());before=B-spent-reserved
        near(log['capacity_before'],before)
        proposal=bool(rows.get(log['k'],{}).get('proposed_action',False))
        assert log['proposal']==proposal
        expected=proposal and before+1e-12>=130.
        assert log['action']==expected
        if expected:
            assert log['k'] not in pending;pending[log['k']]=130.
        if log['k'] in rows:
            assert log['action']==rows[log['k']]['action'];near(log['issued_reserve'],130.)
        near(log['spent_loss'],spent);near(log['settled_increment'],settled)
        near(log['reserved'],sum(pending.values()));near(log['capacity_after'],B-spent-sum(pending.values()))
        assert log['pending_origins']==sorted(pending)
        assert spent+sum(pending.values())<=B+TOL
    assert not pending
    near(spent,metrics['negative_loss']);near(settled,metrics['increment'])
    metrics.update(refused=trajectory['refused'],budget=B,minimum_prefix=trajectory['minimum_prefix'])
    return rows,metrics


def audit(physical):
    physical=Path(physical).resolve()
    # Completion gates precede every outcome read, including glob inventories.
    assert (physical/'test_chain_summary.json').is_file(),'Internal test is incomplete.'
    assert (physical/'external/summary.json').is_file(),'External test is incomplete.'
    frozen=load(physical/'algorithm_freeze.json');protocol=load(physical/'protocol.json')
    shared=load(physical/'all_selections_before_test.json');meta=load(physical/'data/cache_metadata.json')
    assert shared['stage']=='all_physical_controller_selections_locked_before_test'
    for path,want in frozen['source_hashes'].items():assert sha(path)==want,path
    for path,want in shared['inputs'].items():assert sha(path)==want,path
    assert sha(physical/'data/cached_dataset.npz')==shared['cache_sha256']==meta['cache_sha256']
    selection=load(physical/'selection.json')['selected'];external=load(physical/'external/selection.json')['selected']
    assert set(selection)==set(frozen['arms'])
    ext_protocol=load(physical/'external/protocol.json')
    for path,want in ext_protocol['input_sha256'].items():assert sha(path)==want,path
    for path,names in ((physical/'before_test.json',dict(selection_sha256='selection.json',algorithm_freeze_sha256='algorithm_freeze.json',cache_metadata_sha256='data/cache_metadata.json')),
        (physical/'external/selection_freeze.json',dict(selection_sha256='external/selection.json',protocol_sha256='external/protocol.json',algorithm_freeze_sha256='algorithm_freeze.json',cache_metadata_sha256='data/cache_metadata.json'))):
        record=load(path)
        for name,rel in names.items():assert record[name]==sha(physical/rel)
        assert record['cache_sha256']==meta['cache_sha256']
    binding=load(physical/'EXECUTION_TEST_BINDING.json')
    for name,rel in dict(all_selections_before_test_sha256='all_selections_before_test.json',execution_cache_sha256='execution_cache.py',
        prefix_cache_proof_sha256='execution_cache_report.json',external_calibration_validation_sha256='external_calibration_validation.json').items():
        assert binding[name]==sha(physical/rel),name
    assert not binding['scientific_method_changed']
    summary=load(physical/'test_chain_summary.json');records=summary['records']
    recordings={r['recording']:r['person'] for r in records};assert len(recordings)==len(records)==summary['test_run_count']
    assert set(recordings.values())==set(meta['test_participants'])==set(summary['test_participants'])
    seeds=set(frozen['test_seeds']);budgets=set(frozen['execution']['diagnostic_budgets']);arms=set(frozen['arms'])
    primary=frozen['primary'];matched={a for a in arms if not a.startswith('legacy_')}
    names=[r.replace('/','_') for r in recordings];assert len(names)==len(set(names))
    expected=set(names)
    for suffix in ('_results.json.gz','_guarded.json.gz','_fixed_state.json.gz','_verification.json'):
        assert {p.name[:-len(suffix)] for p in physical.glob('S*'+suffix)}==expected,suffix
    assert {p.name[:-len('_results.json.gz')] for p in (physical/'external').glob('S*_results.json.gz')}==expected
    totals=collections.defaultdict(lambda:collections.defaultdict(float));policy_terms=collections.defaultdict(lambda:collections.defaultdict(float))
    fixed_terms=collections.defaultdict(lambda:collections.defaultdict(float));internal_original={};guard_lookup={}
    counts=dict(policy_trajectories=0,budget_trajectories=0,fixed_origins=0,callbacks=0)
    def add(key,values):
        for name in ('admissions','beneficial','harmful','zero','covered','violations','negative_loss','increment','optimistic_excess','refused'):
            totals[key][name]+=values.get(name,0)
    for recording,person in recordings.items():
        stem=recording.replace('/','_');trials=load(physical/(stem+'_results.json.gz'))
        assert {t['seed'] for t in trials}==seeds and len(trials)==len(seeds)
        verification=load(physical/(stem+'_verification.json'));assert verification['passed']
        assert verification['max_service_error']<TOL
        original={}
        for trial in trials:
            assert trial['recording']==recording and set(trial['results'])==arms
            for arm,result in trial['results'].items():
                assert trial['checks'][arm]['passed'];assert result['solver_failures']==0
                cb=audit_callbacks(result,selection[arm]['q_initial'],selection[arm]['q_floor'])
                counts['callbacks']+=cb['callbacks'];counts['policy_trajectories']+=1
                original[trial['seed'],arm]=result;internal_original[recording,trial['seed'],arm]=result
                near(result['net']-trial['reference']['net'],row_metrics(result['rows'])['increment'])
        guarded=load(physical/(stem+'_guarded.json.gz'))
        keys={(g['seed'],g['arm'],g['budget']) for g in guarded}
        assert len(keys)==len(guarded) and keys=={(s,a,b) for s in seeds for a in arms for b in budgets}
        for g in guarded:
            assert g['recording']==recording and g['person']==person
            rows,metrics=audit_guard(g,original[g['seed'],g['arm']]);counts['budget_trajectories']+=1
            add((g['arm'],g['budget']),metrics);guard_lookup[recording,g['seed'],g['arm'],g['budget']]=(rows,g['increment'])
        fixed=load(physical/(stem+'_fixed_state.json.gz'));fixed_keys={(f['seed'],f['k']) for f in fixed}
        wanted={(s,r['k']) for s in seeds for r in original[s,primary]['rows']}
        assert len(fixed)==len(fixed_keys) and fixed_keys==wanted
        for f in fixed:
            assert f['recording']==recording and set(f['predictions'])==matched
            row=indexed(original[f['seed'],primary]['rows'])[f['k']]
            near(f['q'],row['q_issued']);near(f['local_net'],row['local_net'])
            predictions=f['predictions'];P=predictions[primary]
            near(P['F'],row['gain']);near(P['S'],row['posterior_or_block_sd'])
            assert P['action']==row['action']
            for arm,p in predictions.items():
                near(p['score'],p['F']-f['q']*p['S']-5);assert p['action']==(p['score']>0)
                if arm==primary:continue
                terms=four_terms({f['k']:dict(action=P['action'],local_net=f['local_net'])},
                    {f['k']:dict(action=p['action'],local_net=f['local_net'])})
                for name,value in terms.items():fixed_terms[arm][name]+=value
            counts['fixed_origins']+=1
    ext_guarded=load(physical/'external/guarded_all.json.gz');ext_index={}
    for g in ext_guarded:
        key=(g['recording'],g['seed'],g['rule'],g['budget']);assert key not in ext_index;ext_index[key]=g
    assert set(ext_index)=={(r,s,a,b) for r in recordings for s in seeds for a in external for b in budgets}
    for recording,person in recordings.items():
        obj=load(physical/'external'/(recording.replace('/','_')+'_results.json.gz'));trials=obj['trials']
        assert {t['seed'] for t in trials}==seeds and len(trials)==len(seeds)
        local_keys={(g['recording'],g['seed'],g['rule'],g['budget']) for g in obj['guarded']}
        assert len(local_keys)==len(obj['guarded']) and local_keys=={(recording,s,a,b) for s in seeds for a in external for b in budgets}
        for g in obj['guarded']:assert g==ext_index[g['recording'],g['seed'],g['rule'],g['budget']]
        for trial in trials:
            assert trial['recording']==recording and trial['person']==person and set(trial['results'])==set(external)
            for rule,result in trial['results'].items():
                assert trial['checks'][rule]['passed'];assert result['solver_failures']==0
                cb=audit_callbacks(result,external[rule]['q0'],0.);counts['callbacks']+=cb['callbacks'];counts['policy_trajectories']+=1
                for row in result['rows']:
                    near(row['gate_score'],row['gain']-row['q_issued']*row['posterior_or_block_sd']-5-external[rule]['margin'])
                    assert row['action']==(row['gate_score']>0)
                for B in budgets:
                    g=ext_index[recording,trial['seed'],rule,B];assert g['person']==person
                    rows,metrics=audit_guard(g,result);counts['budget_trajectories']+=1
                    arm=rule+'_MLP';add((arm,B),metrics);guard_lookup[recording,trial['seed'],arm,B]=(rows,g['increment'])
    all_arms=arms|{a+'_MLP' for a in external}
    for recording in recordings:
        for seed in seeds:
            pr,pi=guard_lookup[recording,seed,primary,130.]
            for arm in all_arms-{primary}:
                cr,ci=guard_lookup[recording,seed,arm,130.];terms=four_terms(pr,cr)
                near(terms['direct_difference'],pi-ci)
                for name,value in terms.items():policy_terms[arm][name]+=value
    return dict(status='passed',scientific_sources_unchanged=True,source_count=len(frozen['source_hashes']),
        all_selection_locks_verified=True,test_participants=sorted(set(recordings.values())),
        test_run_count=len(recordings),delay_schedules=sorted(seeds),counts=counts,
        pooled_budget_metrics={arm+':B'+str(B):dict(values) for (arm,B),values in totals.items()},
        pooled_primary_minus_policy={a:dict(v) for a,v in policy_terms.items()},
        fixed_primary_state_proposal_interventions={a:dict(v) for a,v in fixed_terms.items()},
        pooling_scope='All runs and five shared schedules pooled; divide return differences by5 for collection means. Schedules reuse observations.',
        fixed_state_scope='Proposal-only at identical CJ h/history/bandwidth/issued q; cannot be interpreted as executed sequential returns.',
        feature_or_label_arrays_reopened=False,fitting_or_tests_launched=False,
        source_sha256=sha(__file__),shared_selection_lock_sha256=sha(physical/'all_selections_before_test.json'))


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--physical',type=Path,default=DEFAULT)
    ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
    assert not args.output.exists(),'Preserve earlier audits.'
    report=audit(args.physical);args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(status=report['status'],test_run_count=report['test_run_count'],counts=report['counts']),indent=2))


if __name__=='__main__':main()
