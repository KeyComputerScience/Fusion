# Frozen CJ/HARTH reproduction

The active method is original conditional joint CJ with its original delayed
mean/standard-deviation gate. Development candidates CJ-R, CJ-T and CJ-Q failed
to improve known RSS return and were not promoted. Their complete archived
development outcomes are retained when the builder includes development files.

This self-contained directory preserves all 28 files bound by the final HARTH
algorithm freeze in their original project-relative locations under `project/`.
`SOURCE_IDENTITIES.json` and `MANIFEST.json` bind the unchanged scientific bytes.
The launcher changes filesystem bindings in memory; it does not change fusion,
fitting, quantiles, calibration, optimization, actions or service code.

Python 3.11 or later and NumPy are required. The recorded physical runtime is
Python 3.12.14/NumPy 2.3.5. No network or raw archive is required. The processed
cache includes labels needed for reproduction; loading it is a replay of the
recorded study, not a new prospective validation. New outputs must be outside
this delivered package. Initial calibration creates fresh selections rather
than importing archived selections.

```sh
python run_reproduction.py verify
python run_reproduction.py theory --output /absolute/fresh/theory
python run_reproduction.py physical-calibrate --output /absolute/fresh/replay
python run_reproduction.py external-calibrate --output /absolute/fresh/replay
python run_reproduction.py locktest --output /absolute/fresh/replay
python run_reproduction.py physical-test --output /absolute/fresh/replay
python run_reproduction.py external-test --output /absolute/fresh/replay
python run_reproduction.py analyze --output /absolute/fresh/archived-analysis
```

Use the same output for the five calibration/lock/test phases. Each phase runs
in a separate Python process. Historical freezes and acquisition authorization
stay byte-identical; their old absolute paths resolve only to copied files in
the replay project. Fresh replay locks use the new output paths. These locks
establish reproducibility and do not create a new preregistration.

The theory command reruns the independent constructed-state/API/source-closure
audit and conditional information-separation example without reading physical
outcomes. The analysis command copies all delivered physical records to a fresh
output and recomputes the analysis. It needs a package built after both internal
and external tests completed. A source-only audit package supports `verify` and
`theory`; the physical replay commands additionally require the processed cache.

The final physical protocol uses eight fit participants, four calibration
participants and ten withheld participants, with separate histories at raw
timestamp gaps. Delay schedules reuse physical observations and do not add
independent participants. All arms share the execution guard; posterior
calibration and superior profit are not guaranteed. Every comparison outcome,
loss, abstention, refused action and admitted-coverage denominator must be
reported. `MANUSCRIPT_POINTER.json` identifies the manuscript snapshot at build
time; the final separately supplied manuscript remains authoritative.

For maintainers, run the original workspace's
`work/fusion_cj_next_20261004/reproduction/build_package.py --output NEW_DIRECTORY --include-results`
to create a final copy after both test pipelines finish. The builder included
here records that packaging procedure and expects the original workspace.
`--sources-only` creates
a data-free source audit copy. The builder does not copy the official raw ZIP.
It preserves cache/provenance files and complete results as opaque file bytes.

See `LICENSES.md` for dataset and method attribution.
