# Frozen CJ/HARTH reproduction

The active method is original conditional joint CJ with its original delayed
mean/standard-deviation gate. Development candidates CJ-R, CJ-T and CJ-Q failed
to improve known RSS return and were not promoted. Their complete archived
development outcomes are retained when the builder includes development files.

This self-contained directory preserves all 28 files bound by the final HARTH
algorithm freeze in their original project-relative locations under `project/`.
`SOURCE_IDENTITIES.json` and `MANIFEST.json` bind the unchanged scientific bytes.
The launcher changes filesystem bindings in memory; it does not change fusion,
fitting, quantiles, calibration, optimization, actions or service code.

The pre-acquisition and pre-header-repair freezes are retained with their
original source bytes, authorizations and acquisition records. Initial ingestion
stopped at export-index columns before any fitting; the narrowly authorized
header repair accepts only an inert named/unnamed index beside the unchanged
scientific fields. `SCHEMA_HEADER_AMENDMENT.json` records that chronology.
Operative source hashes bind the amended parser; the numerical method and
selectors remain unchanged. The historical snapshots are provenance records
and are not substituted for the operative freeze used by the replay.

The optional `physical/execution_cache.py` wrapper and its prefix-only
equivalence proof are preserved separately from the scientific source freeze.
It memoizes only identical supplied-model twenty-step neural training calls
on buffers larger than the frozen online buffer, using full byte hashes and
deep copies. Cold calls, cache misses and hits returned identical PDF/QMF
model arrays and work fields on the actual fit prefix. It changes elapsed
execution and allocation, not training updates or method selection. The
portable launcher below runs the original uncached training by default.
For an equivalent replay of the recorded execution optimization, append
`--cache-prefix-training` to either external command. The flag applies only
to external calibration/test, and writes a separate cache execution audit.

Python 3.11 or later and NumPy are required. The recorded physical runtime is
Python 3.12.14/NumPy 2.3.5. No network or raw archive is required. The processed
cache includes labels needed for reproduction; loading it is a replay of the
recorded study, not a new prospective validation. New outputs must be outside
this delivered package. Initial calibration creates fresh selections rather
than importing archived selections.

```sh
python run_reproduction.py verify
python run_reproduction.py theory --output /absolute/fresh/theory
python run_reproduction.py physical-calibrate --output /absolute/fresh/replay
python run_reproduction.py external-calibrate --output /absolute/fresh/replay
python run_reproduction.py locktest --output /absolute/fresh/replay
python run_reproduction.py physical-test --output /absolute/fresh/replay
python run_reproduction.py external-test --output /absolute/fresh/replay
python run_reproduction.py analyze --output /absolute/fresh/archived-analysis
```

Use the same output for the five calibration/lock/test phases. Each phase runs
in a separate Python process. Historical freezes and acquisition authorization
stay byte-identical; their old absolute paths resolve only to copied files in
the replay project. Fresh replay locks use the new output paths. These locks
establish reproducibility and do not create a new preregistration.

With completed records bundled, calibration/test commands compare all decoded
scientific records with the archive: actions and discrete structure must match
exactly, numeric leaves use absolute tolerance `1e-10` plus relative tolerance
`1e-12`, and the maximum observed difference is recorded. New path/timestamp
lock files are excluded from that comparison. Exact decoded equality is also
reported separately.

The theory command reruns the independent constructed-state/API/source-closure
audit, conditional information-separation example, and exact finite paid-gate
regret/benefit proof checks without reading physical outcomes. The analysis
command copies all delivered physical records to a fresh
output, reruns the independent completed-record source/lock/callback/ledger
and action-gain audit, and recomputes the analysis. It needs a package built after both internal
and external tests completed. A source-only audit package supports `verify` and
`theory`; the physical replay commands additionally require the processed cache.

The final physical protocol uses eight fit participants, four calibration
participants and ten withheld participants, with separate histories at raw
timestamp gaps. Delay schedules reuse physical observations and do not add
independent participants. All arms share the execution guard; posterior
calibration and superior profit are not guaranteed. Every comparison outcome,
loss, abstention, refused action and admitted-coverage denominator must be
reported. `MANUSCRIPT_POINTER.json` identifies the manuscript snapshot at build
time; the final separately supplied manuscript remains authoritative.

For maintainers, run the original workspace's
`work/fusion_cj_next_20261004/reproduction/build_package.py --output NEW_DIRECTORY --include-results`
to create a final copy after both test pipelines finish. The builder included
here records that packaging procedure and expects the original workspace.
`--sources-only` creates
a data-free source audit copy. The builder does not copy the official raw ZIP.
It preserves cache/provenance files and complete results as opaque file bytes.

See `LICENSES.md` for dataset and method attribution.
